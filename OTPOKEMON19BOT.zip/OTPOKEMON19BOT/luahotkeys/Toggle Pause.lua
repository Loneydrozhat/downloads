if getOption("Global/BotPaused") == "true" then
	setOption("Global/BotPaused", "false")
else
	setOption("Global/BotPaused", "true")
end