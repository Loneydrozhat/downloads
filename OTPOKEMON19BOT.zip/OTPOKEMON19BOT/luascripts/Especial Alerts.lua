-- [SHINY AND HORDER ALERT]
-- Pergunta: O que posso alterar no script?
-- Resposta: Voce pode alterar as variaveis [shinyAlert] [horderAlert] [pauseBot]
-- Pergunta: O que essas variaveis fazem?
-- Resposta: Elas funcionam como um botao, onde "TRUE = LIGADO" e "FALSE = DESLIGADO"
-- Pergunta: Por que tem uma opcao para pausar o bot?
-- Resposta: Sem o cavebot e target atrapalhando, voce consegue tomar suas acoes com facilidade

local shinyAlert = true
local horderAlert = true
local pauseBot = false
local creatureNames = {"Shiny", "Horde", "Migrating"}
local creatures = g_game.getCreatures()

if #g_game.getMonstersAround(9) >= 1 then
	for _, creature in pairs(creatures) do
		takeNumber = creature:getType()
		takeName = creature:getName()
		if takeNumber == 1 then
			for _, name in pairs(creatureNames) do
				if string.find(takeName, name) then
					playSound(name .. ".wav")
					if pauseBot then
						setOption("Targeting/Enabled", "false")
						setOption("Cavebot/Enabled", "false")
					end
				end
			end
		end
	end
end
auto(2000)