--[AUTO KS]
-- Pergunta? Oque posso alterar no script?
-- Resposta: Voce pode alterar as variaveis [lifePercent], [bossName] e [combo]
-- Pertgunta: O que essas variaveis fazem?
-- Resposta: [lifePercent] Define a porcentagem que ira comecar a atacar
-- Resposta: [bossName] Define o nome do Boss ou Pokemon que quer dar KS
-- Resposta: [combo] Define o combo que o seu pokemon ira utilizar na hora de atacar

local lifePercent = 5
local bossName = {"boss1", "boss2", "boss3"}
local combo = {"m1", "m2", "m3", "m4", "m5", "m6", "m7", "m8"}


local creatures = g_game.getCreatures()

if not g_game.isAttacking() then
	for _, creature in pairs(creatures) do
		creatureName = creature:getName()
		creatureType = creature:getType()
		for _, boss in pairs(bossName) do 
			if string.find(creatureName, boss) and creatureType == 1 then
				creatureLife = creature:getHealthPercent()
				if creatureLife <= lifePercent then
					g_game.attack(creature)
				end
			end
		end
	end
end

if g_game.isAttacking() then
	for _, move in pairs(combo) do
		g_game.talk(move)
	end
end
auto(100)