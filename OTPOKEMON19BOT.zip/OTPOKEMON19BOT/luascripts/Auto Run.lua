-- [AUTO RUN]
local player = g_game.getLocalPlayer()
local spellToCast = "run"

if not player:hasState(PlayerStates.Haste) then
    g_game.talk(spellToCast)
end
auto(200)