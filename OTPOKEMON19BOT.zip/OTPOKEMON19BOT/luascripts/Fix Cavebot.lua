--[PAUSE CAVEBOT WHILE TARGET]
if g_game.isAttacking() then
	setOption("Cavebot/Enabled", "false")
else
    sleep(1500)
    setOption("Cavebot/Enabled", "true")
end
auto(100)