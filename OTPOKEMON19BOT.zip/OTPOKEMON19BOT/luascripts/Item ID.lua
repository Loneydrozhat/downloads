-- [GET ITEM IDS]
-- Pergunta? Oque posso alterar no script?
-- Resposta: Voce pode alterar a variavel [containerNumber]
-- Pergunta? O que essa variavel faz?
-- Resposta: Ela e responsavel por identicar a mochila aberta
-- Resposta: Exemplo "0 e referente a Backpack" e "1 e referente a Coins" etc...
-- Pergunta? Onde eu vejo o ID dos itens?
-- Resposta: Na barra superior do BOT em MISC, abra o LUA Console e ative o script
-- Dica: "No SLOT" quer dizer onde o item esta localizado dentro da mochila

local containerNumber = 1
local items = g_game.getContainer(containerNumber):getItems()
local itemPosition = g_game.getContainer(containerNumber):getItems()
local containerName = g_game.getContainer(containerNumber):getName()
local count = 0

function takeSlotPosition()
	count = count + 1
	return count
end

if items then
	for _, item in pairs(items) do
		containerNameToString = tostring(containerName)
		itemIdToString = tostring(item:getId())
		takeSlotPosition()
		print("[Este item est? em: " .. containerNameToString .. "] [Possui o ID: " .. itemIdToString .. "]" .. " [No SLOT: " .. count .. "]")
	end
end