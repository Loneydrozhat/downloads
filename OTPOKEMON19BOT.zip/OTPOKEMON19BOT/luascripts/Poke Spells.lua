-- [AUTO SKILLS]
-- Pergunta: O que posso alterar no script?
-- Resposta: Voce pode alterar a variavel [bindSkills]
-- Pergunta: O que essa variavel faz?
-- Resposta: Ela registra as skills que voce quer utilizar
-- Pergunta: Como eu devo alterar?
-- Resposta: Voce deve seguir o mesmo padrao utilizando virgula para separar "skill",

local bindSkills = {"m1", "m2", "m3", "m4", "m5", "m6", "m7", "m8"}

if g_game.isAttacking() then
	for _, skill in pairs(bindSkills) do
		g_game.talk(skill)
	end
end
auto(200)