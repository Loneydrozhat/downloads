-- [AUTO TARGET + COMBO]
-- Pergunta? O que posso alterar no script?
-- Resposta: Voce pode alterar a variavel [distanceToSpells], [distanceToTarget], [pokeTeam], [moveSet], [toggleCombo] e [combo]
-- Pergunta? O que essas variaveis fazem?
-- Resposta: [distanceToTarget] Verifica a distancia entre o Pokemon Selvagem e seu Personagem
-- Resposta: [distanceToTarget] Verifica a distancia entre o seu Pokemon e seu Personagem, para usar o combo
-- Resposta: [pokeTeam] Define os pokemons que esta utilizando e a ordem deles na lista
-- Resposta: [moveSet] Define o combo que cada pokemon vai utilizar, de acordo com a ordem da lista
-- Resposta: [toggleCombo] TRUE para ativar e FALSE para desativar o uso se spells neste script
-- Resposta: [Combo] Voce pode escolher quais magias seu Pokemon deve utilizar no combo e a ordem delas

local distanceToSpells = 2
local distanceToTarget = 4
local pokeTeam = {"Starmie", "Segundo Poke", "Terceiro Poke", "Jolteon", "Quinto Poke", "Sexto Poke"}
local moveSet1 = {"m1", "m2", "m3", "m4", "m5", "m6", "m7" , "m8"} -- Pokemon 1
local moveSet2 = {"m1", "m2", "m3", "m4", "m5", "m6", "m7" , "m8"} -- Pokemon 2
local moveSet3 = {"m1", "m2", "m3", "m4", "m5", "m6", "m7" , "m8"} -- Pokemon 3
local moveSet4 = {"m5", "m2", "m3", "m4", "m1", "m6", "m7" , "m8"} -- Pokemon 4
local moveSet5 = {"m1", "m2", "m3", "m4", "m5", "m6", "m7" , "m8"} -- Pokemon 5
local moveSet6 = {"m1", "m2", "m3", "m4", "m5", "m6", "m7" , "m8"} -- Pokemon 6
local toggleCombo = true

local screenCreatures = g_game.getCreatures()
local mainPlayer = g_game.getLocalPlayer()

if #g_game.getMonstersAround(distanceToTarget) >= 1 then
	for _, creature in pairs(screenCreatures) do
		creatureType = creature:getType()
		creaturePosition = creature:getPosition()
		if creatureType == 1 and mainPlayer:getPosition():getDistance(creaturePosition) <= distanceToTarget then
			if not g_game.isAttacking() then
                sleep(500)
				g_game.attack(creature)
			end
		end
		if g_game.isAttacking() and toggleCombo == true then
			for _, creature in pairs(screenCreatures) do
				creatureType = creature:getType()
				creaturePosition2 = creature:getPosition()
				if creatureType == 3 and mainPlayer:getPosition():getDistance(creaturePosition2) <= distanceToSpells then
					for pos, name in ipairs(pokeTeam) do
						creatureName = creature:getName()
						if string.find(creatureName, name) then
							if pos == 1 then
								for _, move in pairs(moveSet1) do
									g_game.talk(move)
								end
							end
							if pos == 2 then
								for _, move in pairs(moveSet2) do
									g_game.talk(move)
								end
							end
							if pos == 3 then
								for _, move in pairs(moveSet3) do
									g_game.talk(move)
								end
							end
							if pos == 4 then
								for _, move in pairs(moveSet4) do
									g_game.talk(move)
								end
							end
							if pos == 5 then
								for _, move in pairs(moveSet5) do
									g_game.talk(move)
								end
							end
							if pos == 6 then
								for _, move in pairs(moveSet6) do
									g_game.talk(move)
								end
							end
						end
					end
				end
			end
		end		
	end
end
auto(100)