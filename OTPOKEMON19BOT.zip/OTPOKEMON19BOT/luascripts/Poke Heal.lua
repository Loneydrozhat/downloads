-- [AUTO HEAL]
-- Pergunta: O que posso alterar no script?
-- Resposta: Voc? pode alterar as variaveis [pokeTeam], [moveSet] e [Heal]
-- Pergunta: O que essas variaveis fazem?
-- Resposta: [pokeTeam] Verifica o nome do seu pokemon e a ordem em que ele esta na lista
-- Resposta: [moveSet] Define quais moves seus pokemons vao usar, de acordo com a lista
-- Resposta: [Heal] Define as porcentagens alta, media e baixa para usar de acordo com a ordem da lista
-- Observa??o: Lembre-se de nao utilizar o heal no seu combo | full heal usara todas habilidades do movesetHeal ao mesmo tempo

local pokeTeam = {"Starmie", "Segundo Poke", "Terceiro Poke", "Quarto Poke", "Jolteon", "Sexto Poke"}
local moveSetHeal1 = {"m9"} -- Pokemon 1
local moveSetHeal2 = {"m1", "m2", "m9"} -- Pokemon 2
local moveSetHeal3 = {"m1", "m2", "m9"} -- Pokemon 3
local moveSetHeal4 = {"m1", "m2", "m9"} -- Pokemon 4
local moveSetHeal5 = {"m9"} -- Pokemon 5
local moveSetHeal6 = {"m1", "m2", "m9"} -- Pokemon 6
local highHeal = 75
local mediumHeal = 70
local lowHeal = 50
local fullHeal = 40

local creatures = g_game.getCreatures()

if g_game.isOnline() then
	for _, creature in pairs(creatures) do
		creatureType = creature:getType()
		if creatureType == 3 then
			for teamPos, name in pairs(pokeTeam) do
				creatureName = creature:getName()
				if string.find(creatureName, name) then
					if teamPos == 1 then -- Poke 1
						for healPos, move in pairs(moveSetHeal1) do
							if creature:getHealthPercent() <= highHeal and healPos == 1 then
								g_game.talk(move)
							end
							if creature:getHealthPercent() <= mediumHeal and healPos == 2 then
								g_game.talk(move)
							end
							if creature:getHealthPercent() <= lowHeal and healPos == 3 then
								g_game.talk(move)
							end
							if creature:getHealthPercent() <= fullHeal then
								g_game.talk(move)
							end
						end
					end
					if teamPos == 2 then -- Poke 2
						for healPos, move in pairs(moveSetHeal2) do
							if creature:getHealthPercent() <= highHeal and healPos == 1 then
								g_game.talk(move)
							end
							if creature:getHealthPercent() <= mediumHeal and healPos == 2 then
								g_game.talk(move)
							end
							if creature:getHealthPercent() <= lowHeal and healPos == 3 then
								g_game.talk(move)
							end
							if creature:getHealthPercent() <= fullHeal then
								g_game.talk(move)
							end
						end
					end
					if teamPos == 3 then -- Poke 3
						for healPos, move in pairs(moveSetHeal3) do
							if creature:getHealthPercent() <= highHeal and healPos == 1 then
								g_game.talk(move)
							end
							if creature:getHealthPercent() <= mediumHeal and healPos == 2 then
								g_game.talk(move)
							end
							if creature:getHealthPercent() <= lowHeal and healPos == 3 then
								g_game.talk(move)
							end
							if creature:getHealthPercent() <= fullHeal then
								g_game.talk(move)
							end
						end
					end
					if teamPos == 4 then -- Poke 4
						for healPos, move in pairs(moveSetHeal4) do
							if creature:getHealthPercent() <= highHeal and healPos == 1 then
								g_game.talk(move)
							end
							if creature:getHealthPercent() <= mediumHeal and healPos == 2 then
								g_game.talk(move)
							end
							if creature:getHealthPercent() <= lowHeal and healPos == 3 then
								g_game.talk(move)
							end
							if creature:getHealthPercent() <= fullHeal then
								g_game.talk(move)
							end
						end
					end
					if teamPos == 5 then -- Poke 5
						for healPos, move in pairs(moveSetHeal5) do
							if creature:getHealthPercent() <= highHeal and healPos == 1 then
								g_game.talk(move)
							end
							if creature:getHealthPercent() <= mediumHeal and healPos == 2 then
								g_game.talk(move)
							end
							if creature:getHealthPercent() <= lowHeal and healPos == 3 then
								g_game.talk(move)
							end
							if creature:getHealthPercent() <= fullHeal then
								g_game.talk(move)
							end
						end
					end
					if teamPos == 6 then -- Poke 6
						for healPos, move in pairs(moveSetHeal6) do
							if creature:getHealthPercent() <= highHeal and healPos == 1 then
								g_game.talk(move)
							end
							if creature:getHealthPercent() <= mediumHeal and healPos == 2 then
								g_game.talk(move)
							end
							if creature:getHealthPercent() <= lowHeal and healPos == 3 then
								g_game.talk(move)
							end
							if creature:getHealthPercent() <= fullHeal then
								g_game.talk(move)
							end
						end
					end
				end
			end
		end
	end
end
auto(1000)
