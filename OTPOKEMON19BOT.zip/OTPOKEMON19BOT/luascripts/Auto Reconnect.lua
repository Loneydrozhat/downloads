if not g_game.isOnline() then
	g_game.reconnect()
	sleep(5000)
end
auto(100)