--[AUTO CAPTURE]
-- Pergunta? O que posso alterar no script?
-- Resposta: Voce pode alterar as variaveis [captureNames] e [pokeBallId]
-- Pergunta? O que essas variaveis fazem?
-- Resposta: [captureNames] Define os pokemons que quer capturar
-- Resposta: [pokeBallId] Define o ID da pokeball que ira utilizar para capturar
-- OBS: Este script nao ira capturar cem por cento, mas foi o mais proximo que conseguimos chegar de um script de captura

local captureNames = {"Diglett", "Cubone", "Dugtrio", "Parasect"}
local pokeBallId = 3032

local function saveLastPosition(position)
  local file = assert(io.open("last_position.txt", "w"))
  if position then
    file:write(position.x .. "," .. position.y .. "," .. position.z)
  end
  file:close()
end

local function loadLastPosition()
  local file = io.open("last_position.txt", "r")
  if file then
    local content = file:read("*line")
    file:close()
    if content then
      local x, y, z = content:match("([^,]+),([^,]+),([^,]+)")
      if x and y and z then
        return {x = tonumber(x), y = tonumber(y), z = tonumber(z)}
      end
    end
  end
  return nil
end

if g_game.isAttacking() then
  local creature = g_game.getAttackingCreature()
  local creatureName = creature:getName()
  for _, name in pairs(captureNames) do
    if string.find(creatureName, name) then
      local creaturePosition = creature:getPosition()
      if creature:getHealthPercent() >= 0 then
        saveLastPosition(creaturePosition)
      end
    end
  end
end

if not g_game.isAttacking() then
  local lastPosition = loadLastPosition()
  if lastPosition then
    local targetPosition = Position(lastPosition.x, lastPosition.y, lastPosition.z)
	sleep(900)
    g_game.useItemOnPosition(pokeBallId, targetPosition)
    g_game.useItemOnPosition(pokeBallId, targetPosition)
    g_game.useItemOnPosition(pokeBallId, targetPosition)
    saveLastPosition(nil)
  end
end
auto(100)